﻿using System;
using System.Threading.Tasks;

using Shouldly;

using Xunit;

namespace WeCantSpell.Hunspell.Tests;

public class Issue106Tests : IAsyncLifetime
{
    private WordList _wordListFr = null!;
    private WordList _wordListEs = null!;

    public async ValueTask InitializeAsync()
    {
        _wordListFr = await DictionaryLoader.GetDictionaryAsync("files/French.dic", TestContext.Current.CancellationToken);
        _wordListEs = await DictionaryLoader.GetDictionaryAsync("files/Spanish.dic", TestContext.Current.CancellationToken);
    }

#pragma warning disable CS1998 // Async method lacks 'await' operators and will run synchronously
    public async ValueTask DisposeAsync() { }
#pragma warning restore CS1998 // Async method lacks 'await' operators and will run synchronously

    [Fact]
    public void can_suggest_fr_designation()
    {
        var given = "Designation";
        var actual = _wordListFr.Suggest(
            given,
            new QueryOptions()
            {
                TimeLimitSuggestStep = TimeSpan.FromSeconds(1),
                TimeLimitCompoundCheck = TimeSpan.FromSeconds(1),
                TimeLimitCompoundSuggest = TimeSpan.FromSeconds(1),
                TimeLimitSuggestGlobal = TimeSpan.FromSeconds(10),
            },
            TestContext.Current.CancellationToken);
        actual.ShouldContain("Désignation", StringComparer.Ordinal);
    }

    [Fact]
    public void can_suggest_es_descripcion()
    {
        var given = "Descripcion";
        var actual = _wordListEs.Suggest(
            given,
            new QueryOptions()
            {
                TimeLimitSuggestStep = TimeSpan.FromSeconds(1),
                TimeLimitCompoundCheck = TimeSpan.FromSeconds(1),
                TimeLimitCompoundSuggest = TimeSpan.FromSeconds(1),
                TimeLimitSuggestGlobal = TimeSpan.FromSeconds(10),
            },
            TestContext.Current.CancellationToken);
        // I don't know why but net48 randomly changes the case of the first letter.
        // It's probably worth investingating further and creating a new test for that
        // when the issue there is understood.
        actual.ShouldContain("Descripción", StringComparer.Ordinal);
    }
}
